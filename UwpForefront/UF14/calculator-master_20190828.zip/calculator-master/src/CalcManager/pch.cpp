// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.

// Intentionally do not include the pch.h here. For projects that don't
// use precompiled headers, including the header here would force unnecessary compilation.
// The pch will be included through forced include.
